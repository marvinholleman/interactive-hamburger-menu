Kaliber technical test
Built with Create React app and CSS modules.

Steps to reproduce:
1 yarn install
2 yarn start || yarn build
